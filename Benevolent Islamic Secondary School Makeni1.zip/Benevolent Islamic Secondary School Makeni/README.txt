BENEVOLENT ISLAMIC SECONDARY SCHOOL, MAKENI - WEBSITE PROJECT

FOLDERS
  website/   index.html (the whole website) and logo.jpg
  database/  firestore.rules and database-structure.md

SET UP THE DATABASE (Firebase, free)
 1. console.firebase.google.com > Create project "biss-makeni".
 2. Register a Web app (</>) and copy the firebaseConfig values.
 3. Open website/index.html, find "STEP 1: PASTE YOUR FIREBASE CONFIG HERE" and replace the PASTE_ values.
 4. Build > Firestore Database > Create database (Production mode).
 5. Firestore > Rules: paste database/firestore.rules and Publish.
 6. Build > Authentication > Enable Email/Password > Add user festusamadukamara@gmail.com with a STRONG password.
 7. Authentication > Settings > Authorized domains: add your GitHub address (e.g. festus6-art.github.io).

PUBLISH ON GITHUB PAGES
 1. github.com > New repository "biss-makeni" (Public, license: None).
 2. Upload everything inside the website folder (index.html, logo.jpg).
 3. Settings > Pages > Deploy from branch: main, / (root) > Save.
 4. Live at https://YOUR-USERNAME.github.io/biss-makeni/

ADMIN
 Footer > Admin Dashboard > log in with the admin email and your Firebase password.
