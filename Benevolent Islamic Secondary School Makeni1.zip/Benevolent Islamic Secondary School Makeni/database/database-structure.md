# Database structure (Firebase Firestore)

## Collection: registrations
Created by the Register page. Fields: id, name, email, phone, role, cls, address, message, created (ISO date).

## Collection: messages
Created by the Contact page. Fields: id, name, email, message, created (ISO date).

## Access
Anyone can create entries. Only the admin account (festusamadukamara@gmail.com) can read or delete them.
Rules are in firestore.rules.
